export class HomeModel{
    searchitemby:string;
    searchitem:string;
}
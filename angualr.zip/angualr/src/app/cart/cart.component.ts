import { Component, OnInit } from '@angular/core';
import { CartModel } from '../cart.model';
import { HomeService } from '../home.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  carts:CartModel[];
cart:CartModel;
id:number;
  constructor( private cartService: HomeService,private router:Router) { }

  ngOnInit() {
    this.cartService.getCart(this.id).subscribe( data => {
        this.carts = data;
      });
  }
  remove(cart:CartModel){
    this.cartService.deletecart(cart).subscribe(data => {
       });
       this.router.navigate(['user']);
  }
}

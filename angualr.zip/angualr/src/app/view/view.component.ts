import { Component, OnInit } from '@angular/core';
import { ProductModel } from 'src/product.model';
import { HomeService } from '../home.service';
import { CartModel } from '../cart.model';
import { wishlist } from '../wishlist.model';
import { Router } from '@angular/router';


@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  product:ProductModel;
  cart:CartModel;
  wish:wishlist;
  constructor(private service:HomeService,private router:Router) { }

  ngOnInit() {
   
    this.service.getProduct().subscribe(data=>{this.product= data,console.log(this.product)});
    this.product= new ProductModel();
    this.cart=new CartModel();
  }

  addCart(){
    this.service.addtoCart(this.product).subscribe();
  var ans=confirm("added to cart");
  if(ans)
  {
    this.router.navigate(['cart']);
  }
  
    

 
  }

  addWish()
  {
    this.service.addtowish(this.product,).subscribe(data=>{});
    var ans=confirm("added to wishlist");
    if(ans)
    {
      this.router.navigate(['wishlist']);
    }
  }

}

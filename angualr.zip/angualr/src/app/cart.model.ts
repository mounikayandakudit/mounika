import { ProductModel } from "src/product.model";

export class CartModel{
    public cartId:number;
    public cust_id:number;
    public pro_id:ProductModel;
	public total:number;
    public qty:number;
}
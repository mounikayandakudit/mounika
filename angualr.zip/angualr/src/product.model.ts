export class ProductModel{
    id:number;
    name:string;
    brand:string;
    price:number;
    discount:number;
    promo_code:string;
    stock:number;
    category :string;
    sub_category:string;
    vote_count:number;
    prev_vote_sum:number;
    merchant_id:number;
    searchitemby:string;
    searchitem:string
} 
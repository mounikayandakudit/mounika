import { Component, OnInit } from '@angular/core';
import { CustomerModel } from '../customer.model';
import { HomeService } from '../home.service';

@Component({
  selector: 'app-proile',
  templateUrl: './proile.component.html',
  styleUrls: ['./proile.component.css']
})
export class ProileComponent implements OnInit {
  edit:CustomerModel;
  id:number;
    constructor(private service:HomeService) { 
      this.edit=new CustomerModel();
      id:this.edit.customer_id;
      id:Number;
    }
  
    ngOnInit() {
     this.service.getCustomerData(this.id).subscribe(data=>this.edit=data);
     this.edit=new CustomerModel();
    }
  
    update(edit:CustomerModel){
      var ans=confirm("are sure u to edit it")
      if(ans)
      {
       
  this.service.updateCustomer(edit.customer_id,edit).subscribe(data=>{this.edit=new CustomerModel()})
    
    }
  }

}

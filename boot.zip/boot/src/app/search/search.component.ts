import { Component, OnInit } from '@angular/core';
import { ProductModel } from 'src/product.model';
import { HomeService } from '../home.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
 products:ProductModel[];

  constructor(private service:HomeService, private router:Router) { }

  ngOnInit() {

  this.products=this.service.getProducts();

  }
  View(product:ProductModel){
    this.service.id=product.id;
    this.router.navigate(['view']);
  }
  sorthightolow(){

  }
  sortlowtohigh(){

  }
  sortbynewarrivals(){
    
  }
  filterbyprice(){

  }
  filterbydiscount(){

  }
  filterbybrand(){
  
  }
}

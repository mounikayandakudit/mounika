export class CartModel{
    public cartId:number;
    public customer_id:number;
    public pro_id:number;
	public total:number;
	public qty:number
}
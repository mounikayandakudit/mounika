export class CustomerModel{
    customer_id:number;
    customer_name:string;
    customer_email:string;
    customer_phone:string;
    customer_address:string;
    customer_aadhar:number;
}
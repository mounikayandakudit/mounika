import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ProductModel } from 'src/product.model';
import { HttpClient } from '@angular/common/http';
import { CartModel } from './cart.model';
import { wishlist } from './wishlist.model';
import { CustomerModel } from './customer.model';


@Injectable({
  providedIn: 'root'
})
export class HomeService {
 products:ProductModel[]=[];
 product:ProductModel;
 cart:CartModel;
 wish:wishlist;
 id:number;
 

 baseUrl: string = 'http://localhost:9090/capstore/';
  constructor(private router:Router, private http:HttpClient) { }
  
  searchByName(product:ProductModel){
    return this.http.get<ProductModel[]>(this.baseUrl + 'product/name/'+product.searchitem);
  }
  searchByCategory(product:ProductModel){
    return this.http.get<ProductModel[]>(this.baseUrl + 'product/category/'+product.searchitem);
  }
  searchByBrand(product:ProductModel){
    return this.http.get<ProductModel[]>(this.baseUrl + 'product/brand/'+product.searchitem);
  }
  saveproducts(prod:ProductModel){
    this.products.push(prod);
  }
  getProduct(){
    return this.http.get<ProductModel>(this.baseUrl + 'product/'+this.id);
  }
  getProducts(){
    return this.products;
  }

  addtoCart(cart:CartModel)
  {
    return this.http.post(this.baseUrl+'add/',cart);
  }

  getCart(id:number) {
    return this.http.get<CartModel[]>(this.baseUrl + 'cart/'+1);
  }

  deletecart(cart:CartModel){
    return this.http.delete(this.baseUrl + 'CartItemDelete/'+cart.cartId);
  }

  addtowish(product:ProductModel){
    return this.http.post(this.baseUrl+'addtowishlist',product);
  }

  getWish(id:number) {
    return this.http.get<wishlist[]>(this.baseUrl + 'getwishlist/'+1);
  }

  deletewish(wish:wishlist){
    return this.http.delete(this.baseUrl + 'deletewish/'+wish.wishId);
  }
  getCustomerData(id:number){
    return this.http.get<CustomerModel>(this.baseUrl+'getCustomer/'+1);

  }

  updateCustomer(id:number,customer:CustomerModel) 
{
 
    return this.http.put(this.baseUrl + 'updateProfile/'+1,customer);
  }

}

import { Component, OnInit } from '@angular/core';
import { ProductModel } from 'src/product.model';
import { HomeService } from '../home.service';
import { CartModel } from '../cart.model';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  product:ProductModel;
  constructor(private service:HomeService) { }

  ngOnInit() {
   
    this.service.getProduct().subscribe(data=>{this.product= data,console.log(this.product)});
    this.product= new ProductModel();
  }

  addCart(cart:CartModel){
    this.service.addtoCart(cart).subscribe(data=>{});
   
  }

  addWish(product:ProductModel)
  {
    this.service.addtowish(product).subscribe(data=>{});
  }

}

package com.cg.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "cartlists")
public class CartList {

	@Id
	@GeneratedValue
	private int cartId;
	private int cust_id;

	@ManyToOne
	@JoinColumn(name = "id", nullable = false)
	private Capg_Product pro_id;
	
	
	public Capg_Product getProduct() {
		return pro_id;
	}

	public void setProduct(Capg_Product pro_id) {
		this.pro_id = pro_id;
	}

	private int total;
	private int qty;

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public int getCust_id() {
		return cust_id;
	}

	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	@Override
	public String toString() {
		return "CartList [cartId=" + cartId + ", cust_id=" + cust_id + ", product=" + pro_id + ", total=" + total
				+ ", qty=" + qty + "]";
	}

	public CartList(int cust_id, Capg_Product pro_id, int total, int qty) {
		this.cust_id = cust_id;
		this.pro_id = pro_id;
		this.total = total;
		this.qty = qty;
	}
	public CartList() {
		// TODO Auto-generated constructor stub
	}
	



}

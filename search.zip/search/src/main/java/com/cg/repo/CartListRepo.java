package com.cg.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.entity.CartList;


public interface CartListRepo extends JpaRepository<CartList, Integer> {

	
	@Query("from CartList where cust_id=:custid")
    public List<CartList> getCartListById(@Param("custid") Integer custid);



}

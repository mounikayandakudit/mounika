package com.cg.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.entity.Capg_Product;

public interface Capg_Search_Repo extends JpaRepository<Capg_Product, Integer>{

	@Query("from Capg_Product where name=:na")
	public List<Capg_Product> getProductByName(@Param("na")String name);
	
	@Query("from Capg_Product where brand=:br")
	public List<Capg_Product> getProductByBrand(@Param("br")String brand);
	
	@Query("from Capg_Product where category=:ca")
	public List<Capg_Product> getProductByCategory(@Param("ca")String category);
	
	@Query("from Product ORDER BY price ASC")
	List<Capg_Product> findAllProductsByPriceAsc();
	
	@Query("from Product ORDER BY price DESC")
	List<Capg_Product> findAllProductsPriceDsc();
	
	@Query("from Product ORDER BY id DESC")
	List<Capg_Product> findAllProductsNewest();
	
	@Query("from Product where price>=999")
	List<Capg_Product> findAllProductsByPrice();
	
	@Query("from CapStore where price <= 999")
	public List<Capg_Product> displayAllPrice();
	
	@Query("from CapStore where price between 1000 and 1499")
	public List<Capg_Product> displayAllPrice1();
	
	@Query("from CapStore where price  between 1500 and 1999")
	public List<Capg_Product> displayAllPrice3();
	
	
	@Query("from CapStore where price  between 2000 and 4999")
	public List<Capg_Product> displayAllPrice4();
	
	
	@Query("from CapStore where price  between 5000 and 9999")
	public List<Capg_Product> displayAllPrice5();
	
	
	@Query("from CapStore where price >=9999")
	public List<Capg_Product> displayAllPrice6();
	
	@Query("from CapStore where brand=:b")
	public List<Capg_Product> getCapStoreByBrand(@Param("b") String brand);
	
	@Query("from CapStore where discount>=50")
	public List<Capg_Product> displayAllDiscount();
	
	@Query("from CapStore where discount>=40")
	public List<Capg_Product> displayAllDiscount1();
	
	@Query("from CapStore where discount>=30")
	public List<Capg_Product> displayAllDiscount2();
	
	@Query("from CapStore where discount>=20")
	public List<Capg_Product> displayAllDiscount3();
	
	@Query("from CapStore where discount>=10")
	public List<Capg_Product> displayAllDiscount4();
	
	@Query("from CapStore where discount<10")
	public List<Capg_Product> displayAllDiscount5();
	
	}


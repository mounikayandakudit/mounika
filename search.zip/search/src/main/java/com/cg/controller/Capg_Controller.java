package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Capg_Product;
import com.cg.entity.CartList;
import com.cg.entity.Customer;
import com.cg.entity.WishList;
import com.cg.service.Capg_Search_Service;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/capstore")
public class Capg_Controller {

	@Autowired
	private Capg_Search_Service service;
	
	@PostMapping(value = "/product/add", consumes = "application/json")
	public String addProducts(@RequestBody Capg_Product pro) {
		if(service.saveProducts(pro))
			return "product saved successfully.";
		else
			return "product cannot be added";
	}

	@GetMapping(value = "/product/{id}",produces = "application/json")
	public Capg_Product getProductById(@PathVariable("id") int id) {
		return service.searchById(id);
	}
	
	@GetMapping(value = "/product/name/{na}", produces = "application/json")
	public List<Capg_Product> searchProductByName(@PathVariable("na") String na){
		return service.getProductByName(na);
	}
	
	
	@GetMapping(value = "/product/brand/{br}", produces = "application/json")
	public List<Capg_Product> searchProductByBrand(@PathVariable("br") String br){
		return service.getProductByBrand(br);
	}
	
	@GetMapping(value = "/product/category/{ca}", produces = "application/json")
	public List<Capg_Product> searchProductByCategory(@PathVariable("ca") String ca){
		return service.getProductByCategory(ca);
	}
	
	@PostMapping(value = "/addtowishlist/{cust_id}", consumes = "application/json")
	public void addtoWishList(@PathVariable int cust_id,@RequestBody Capg_Product p) {
		WishList wishlist=service.getwish(p, cust_id);
		service.addtoWishList(wishlist);
	}

	@GetMapping(value = "/getwishlist/{custid}", produces = "application/json")
	public List<WishList> getWishItemById(@PathVariable("custid") int custid) {
		System.out.println(custid);
		return service.getWishProducts(custid);
	}

	@DeleteMapping(value = "/deletewish/{wishId}", produces = "application/json")
	public List<WishList> deletewish(@PathVariable int wishId) {
		
		System.out.println("successfully deleted");
		return service.deletewish(wishId);
	}

	
	@PostMapping(value = "/cart/add/{cust_id}", consumes = "application/json")
	public String addCart(@PathVariable int cust_id,@RequestBody Capg_Product p) {
		CartList c=service.getcart(p,cust_id);
	 service.addToCart(c);
			return "Product saved successfullly.";
	}
	

	@GetMapping(value = "/cart/{custId}", produces = "application/json")
	public List<CartList> getAllCarts(@PathVariable("custId")int custId) {
		return service.getAll(custId);
	}


	@DeleteMapping(value = "/CartItemDelete/{cartId}", produces = "application/json")
	public void deleteCartItemtById(@PathVariable("cartId") int cartId) {
		service.deletecart(cartId);
	}
	
	
	@GetMapping(value="/getCustomer/{cust_id}",produces="application/json")
	public Customer getCustomer(@PathVariable int cust_id)
	{
		return service.getCustomer(cust_id);
	}
	
	@PutMapping(value = "/updateProfile/{cust_id}")
	public boolean updateCustomer(@PathVariable int cust_id,@RequestBody Customer updatedCustomer) 
	{
	Customer c=service.getCustomer(cust_id);
	c.setCustomer_name(updatedCustomer.getCustomer_name());
		service.updateCustomer(updatedCustomer);
		return true;
	}
	
	//sorting
//	
//	@GetMapping(value="/product/asc", produces = "application/json")
//	public List<Capg_Product> viewALLProductsbyasc(){
//		return service.displayAllByPriceAsc();
//	}
//	
//	@GetMapping(value="/product/dsc", produces = "application/json")
//	public List<Capg_Product> viewALLProductsbydesc(){
//		return service.displayAllByPriceDsc();
//	}
//	
//	
//	@GetMapping(value="/product/new", produces = "application/json")
//	public List<Capg_Product> viewALLProductsbynew(){
//		return service.displayAllByNewest();
//	}

	
	//filtering
	
	
	
}

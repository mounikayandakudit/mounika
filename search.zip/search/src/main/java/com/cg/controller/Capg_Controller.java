package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Capg_Product;
import com.cg.entity.CartList;
import com.cg.entity.Customer;
import com.cg.entity.WishList;
import com.cg.service.Capg_Search_Service;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/capstore")
public class Capg_Controller {

	@Autowired
	private Capg_Search_Service service;
	
	@PostMapping(value = "/product/add", consumes = "application/json")
	public String addProducts(@RequestBody Capg_Product pro) {
		if(service.saveProducts(pro))
			return "product saved successfully.";
		else
			return "product cannot be added";
	}

	@GetMapping(value = "/product/{id}",produces = "application/json")
	public Capg_Product getProductById(@PathVariable("id") int id) {
		return service.searchById(id);
	}
	
	@GetMapping(value = "/product/name/{na}", produces = "application/json")
	public List<Capg_Product> searchProductByName(@PathVariable("na") String na){
		return service.getProductByName(na);
	}
	
	
	@GetMapping(value = "/product/brand/{br}", produces = "application/json")
	public List<Capg_Product> searchProductByBrand(@PathVariable("br") String br){
		return service.getProductByBrand(br);
	}
	
	@GetMapping(value = "/product/category/{ca}", produces = "application/json")
	public List<Capg_Product> searchProductByCategory(@PathVariable("ca") String ca){
		return service.getProductByCategory(ca);
	}
	
	@PostMapping(value = "/addtowishlist", consumes = "application/json")
	public void addtoWishList(@RequestBody WishList wishlist) {
		service.addtoWishList(wishlist);
	}

	@GetMapping(value = "/getwishlist/{custid}", produces = "application/json")
	public List<WishList> getWishItemById(@PathVariable("custid") int custid) {
		System.out.println(custid);
		return service.getWishProducts(custid);
	}

	@DeleteMapping(value = "/deletewish/{wishId}", produces = "application/json")
	public List<WishList> deletewish(@PathVariable int wishId) {
		
		System.out.println("successfully deleted");
		return service.deletewish(wishId);
	}

	
	@PostMapping(value = "/add", consumes = "application/json")
	public String addCart(@RequestBody CartList cart) {
	 service.addToCart(cart);
			return "Product saved successfullly.";
	}
	

	@GetMapping(value = "/cart/{custId}", produces = "application/json")
	public List<CartList> getAllCarts(@PathVariable("custId")int custId) {
		return service.getAll(custId);
	}


	@DeleteMapping(value = "/CartItemDelete/{cartId}", produces = "application/json")
	public void deleteCartItemtById(@PathVariable("cartId") int cartId) {
		service.deletecart(cartId);
	}
	
	
	@GetMapping(value="/getCustomer/{cust_id}",produces="application/json")
	public Customer getCustomer(@PathVariable int cust_id)
	{
		return service.getCustomer(cust_id);
	}
	
	@PutMapping(value = "/updateProfile/{cust_id}")
	public boolean updateCustomer(@PathVariable int cust_id,@RequestBody Customer updatedCustomer) 
	{
	Customer c=service.getCustomer(cust_id);
	c.setCustomer_name(updatedCustomer.getCustomer_name());
		service.updateCustomer(updatedCustomer);
		return true;
	}
	
	@GetMapping(value="/product/asc", produces = "application/json")
	public List<Capg_Product> viewALLProductsbyasc(){
		return service.displayAllByPriceAsc();
	}
	
	@GetMapping(value="/product/dsc", produces = "application/json")
	public List<Capg_Product> viewALLProductsbydesc(){
		return service.displayAllByPriceDsc();
	}
	
	
	@GetMapping(value="/product/new", produces = "application/json")
	public List<Capg_Product> viewALLProductsbynew(){
		return service.displayAllByNewest();
	}
	
	@GetMapping(value="/product/price", produces = "application/json")
	public List<Capg_Product> viewALLProductsbyprice(){
		return service.displayByPrice();
	}
	
	
	
	//filtering
	
	@GetMapping(value = "/product/{b}", produces = "application/json")
	public List<Capg_Product> getProductsByBrand(@PathVariable("b") String b){
		return service.getProductsByBrand(b);
	}
	
	@GetMapping(value = "/product/p1", produces = "application/json")
	public List<Capg_Product> getProductByPricerange1(){
		return service.getProductByPrice();
	}
	
	@GetMapping(value = "/product/p2", produces = "application/json")
	public List<Capg_Product> getProductByPricerange2(){
		return service.getProductByPrice1();
	}
	
	@GetMapping(value = "/product/p3", produces = "application/json")
	public List<Capg_Product> getProductByPricerange3(){
		return service.getProductByPrice3();
	}
	
	@GetMapping(value = "/product/p4", produces = "application/json")
	public List<Capg_Product> getProductByPricerange4(){
		return service.getProductByPrice4();
	}
	
	@GetMapping(value = "/product/p5", produces = "application/json")
	public List<Capg_Product> getProductByPricerange5(){
		return service.getProductByPrice5();
	}
	
	@GetMapping(value = "/product/p6", produces = "application/json")
	public List<Capg_Product> getProductByPricerange6(){
		return service.getProductByPrice6();
	}
	
	
	
	@GetMapping(value = "/product/d1", produces = "application/json")
	public List<Capg_Product> getProductByDiscount1(){
		return service.getProductByDiscount();
	}
	
	@GetMapping(value = "/product/d2", produces = "application/json")
	public List<Capg_Product> getProductByDiscount2(){
		return service.getProductByDiscount1();
	}
	
	@GetMapping(value = "/product/d3", produces = "application/json")
	public List<Capg_Product> getProductByDiscount3(){
		return service.getProductByDiscount2();
	}
	
	@GetMapping(value = "/product/d4", produces = "application/json")
	public List<Capg_Product> getProductByDiscount4(){
		return service.getProductByDiscount3();
	}
	
	@GetMapping(value = "/product/d5", produces = "application/json")
	public List<Capg_Product> getProductByDiscount5(){
		return service.getProductByDiscount4();
	}
	
	@GetMapping(value = "/product/d6", produces = "application/json")
	public List<Capg_Product> getProductByDiscount6(){
		return service.getProductByDiscount5();
	}

	
}

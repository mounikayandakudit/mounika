package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Capg_Product;
import com.cg.entity.CartList;
import com.cg.entity.Customer;
import com.cg.entity.WishList;
import com.cg.repo.Capg_Search_Repo;
import com.cg.repo.CartListRepo;
import com.cg.repo.CustomerRepo;
import com.cg.repo.WishListRepo;

@Service
@Transactional
public class Capg_Search_ServiceImpl implements Capg_Search_Service {

	@Autowired
	private Capg_Search_Repo repo;
	
	@Autowired 
	WishListRepo wishRepo;
	
	@Autowired 
	CartListRepo cartRepo;
	
	@Autowired
	CustomerRepo dao;
	
	@Override
	public boolean saveProducts(Capg_Product se) {
		if (repo.save(se) != null)
			return true;
		else
			return false;
	}

	@Override
	public Capg_Product searchById(int id) {
		return repo.findById(id).get();
	}

	@Override
	public List<Capg_Product> getProductByName(String name) {
		return repo.getProductByName(name);
	}

	@Override
	public List<Capg_Product> getProductByBrand(String brand) {
		return repo.getProductByBrand(brand);
	}

	@Override
	public List<Capg_Product> getProductByCategory(String category) {
		return repo.getProductByCategory(category);
	}
	
	public void addtoWishList(WishList wishlist) {
		wishRepo.save(wishlist);
		
	}
	public List<WishList> getWishProducts(int cust_id) {
		// TODO Auto-generated method stub
		return wishRepo.getWishListById(cust_id);
	}
	public List<WishList> deletewish(int wishId) {
		wishRepo.deleteById(wishId);
		return wishRepo.findAll();
		
	}
	
	
	@Override
	public boolean addToCart(CartList cl) {
		// TODO Auto-generated method stub
		
		 cartRepo.save(cl);
		 return true;
	}
	@Override
	public List<CartList> getAll(int cust_id) {
		// TODO Auto-generated method stub
		return cartRepo.getCartListById(cust_id);
	}

	@Override
	public boolean deletecart(int cart_id) {
		// TODO Auto-generated method stub
		 cartRepo.deleteById(cart_id);
		 return true;
	} 

	
	@Override
	public Customer getCustomer(int cust_id) {
		// TODO Auto-generated method stub
		return dao.findById(cust_id).get();
	}

	@Override
	public boolean updateCustomer(Customer c) {
		// TODO Auto-generated method stub
		 dao.save(c);
		 return true;
	} 
	@Override
	public List<Capg_Product> displayAllByPriceAsc() {

		return repo.findAllProductsByPriceAsc();
	}

	@Override
	public List<Capg_Product> displayAllByPriceDsc() {

			return repo.findAllProductsPriceDsc();	
			                    }

	@Override
	public List<Capg_Product> displayAllByNewest() {
		return repo.findAllProductsNewest();
	}

	@Override
	public List<Capg_Product> displayByPrice() {

		return repo.findAllProductsByPrice();
	}
	
	@Override
	public List<Capg_Product> getProductByPrice() {
		return repo.displayAllPrice();
	}

	@Override
	public List<Capg_Product> getProductByPrice1() {
		return repo.displayAllPrice1();
	}

	@Override
	public List<Capg_Product> getProductByPrice3() {
		return repo.displayAllPrice3();
	}

	@Override
	public List<Capg_Product> getProductByPrice4() {
		return repo.displayAllPrice4();
	}

	@Override
	public List<Capg_Product> getProductByPrice5() {
		return repo.displayAllPrice5();
	}

	@Override
	public List<Capg_Product> getProductByPrice6() {
		return repo.displayAllPrice6();	
	}


	@Override
	public List<Capg_Product> getProductByDiscount() {
		return repo.displayAllDiscount();	
    }

	@Override
	public List<Capg_Product> getProductByDiscount1() {
		return repo.displayAllDiscount1();
	}

	@Override
	public List<Capg_Product> getProductByDiscount2() {
		return repo.displayAllDiscount2();
	}

	@Override
	public List<Capg_Product> getProductByDiscount3() {
		return repo.displayAllDiscount3();
	}

	@Override
	public List<Capg_Product> getProductByDiscount4() {
		return repo.displayAllDiscount4();	}

	@Override
	public List<Capg_Product> getProductByDiscount5() {
		return repo.displayAllDiscount5();	}

	@Override
	public List<Capg_Product> getProductsByBrand(String brand) {
		return repo.getCapStoreByBrand(brand);
	}
	
	
}
